// Film-base palette: deep teal-slate, with one amber "cut marker" accent.
export const c = {
  bg: '#16262B', surface: '#20363C', line: '#31505A',
  text: '#E8F1EF', dim: '#8FA9AD', amber: '#F4B63F', danger: '#E2574C',
};
export const s = { pad: 16, radius: 10 };
