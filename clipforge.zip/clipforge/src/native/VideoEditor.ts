import { requireNativeModule } from 'expo-modules-core';

export type Cue = { startMs: number; endMs: number; text: string };
export type TrimOptions = {
  inputUri: string; outputPath: string; startMs: number; endMs: number;
  aspect: '9:16' | '1:1' | 'original'; height: number; cues: Cue[];
};
type Native = {
  extractAudioWav(inputUri: string, outPath: string): Promise<void>;
  trim(o: TrimOptions): Promise<string>;
  addListener(event: 'onProgress', cb: (e: { progress: number }) => void): { remove(): void };
};
export default requireNativeModule<Native>('VideoEditor');
