import React from 'react';
import { Pressable, Text, View, StyleSheet } from 'react-native';
import { c, s } from './theme';

export const fmt = (ms: number) => {
  const t = Math.floor(ms / 1000);
  return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`;
};

export function Btn({ label, onPress, disabled, quiet }: { label: string; onPress: () => void; disabled?: boolean; quiet?: boolean }) {
  return (
    <Pressable onPress={onPress} disabled={disabled}
      style={[st.btn, quiet && st.quiet, disabled && { opacity: 0.4 }]}>
      <Text style={[st.btnT, quiet && { color: c.text }]}>{label}</Text>
    </Pressable>
  );
}

export function Choice<T extends string | number>({ label, options, value, onChange }: {
  label: string; options: { v: T; t: string }[]; value: T; onChange: (v: T) => void;
}) {
  return (
    <View style={{ marginBottom: 18 }}>
      <Text style={st.label}>{label}</Text>
      <View style={st.row}>
        {options.map((o) => (
          <Pressable key={String(o.v)} onPress={() => onChange(o.v)} style={[st.chip, o.v === value && st.chipOn]}>
            <Text style={{ color: o.v === value ? c.bg : c.text, fontWeight: '600' }}>{o.t}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

export const st = StyleSheet.create({
  screen: { flex: 1, backgroundColor: c.bg, padding: s.pad },
  h1: { color: c.text, fontSize: 26, fontWeight: '700', marginBottom: 6 },
  p: { color: c.dim, fontSize: 15, marginBottom: 16 },
  label: { color: c.dim, fontSize: 13, marginBottom: 8 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1, borderColor: c.line },
  chipOn: { backgroundColor: c.amber, borderColor: c.amber },
  btn: { backgroundColor: c.amber, padding: 14, borderRadius: s.radius, alignItems: 'center' },
  quiet: { backgroundColor: c.surface },
  btnT: { color: c.bg, fontWeight: '700', fontSize: 16 },
  card: { backgroundColor: c.surface, borderRadius: s.radius, padding: 14, marginBottom: 10 },
});
