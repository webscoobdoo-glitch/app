import { Seg, Clip } from '../types';
const p = (n: number, l = 2) => String(n).padStart(l, '0');
const ts = (ms: number) =>
  `${p(Math.floor(ms / 3600000))}:${p(Math.floor(ms / 60000) % 60)}:${p(Math.floor(ms / 1000) % 60)},${p(ms % 1000, 3)}`;

export const toSrt = (segs: Seg[]) =>
  segs.map((s, i) => `${i + 1}\n${ts(s.startMs)} --> ${ts(s.endMs)}\n${s.text.trim()}\n`).join('\n');

/** Cues that overlap the clip, clamped to it and shifted so the clip starts at 0. */
export function clipCues(segs: Seg[], clip: Clip): Seg[] {
  return segs
    .filter((s) => s.endMs > clip.startMs && s.startMs < clip.endMs && s.text.trim())
    .map((s) => ({
      startMs: Math.max(s.startMs, clip.startMs) - clip.startMs,
      endMs: Math.min(s.endMs, clip.endMs) - clip.startMs,
      text: s.text.trim(),
    }));
}
