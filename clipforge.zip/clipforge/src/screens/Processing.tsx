import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { useStore } from '../store';
import { runPipeline } from '../services/pipeline';
import { findHighlights } from '../services/highlights';
import { c } from '../theme';
import { st } from '../ui';

export default function Processing({ navigation }: any) {
  const { videoUri, lang, mode, set } = useStore();
  const [step, setStep] = useState({ label: 'Starting', pct: 0 });
  const [err, setErr] = useState<string>();

  useEffect(() => {
    (async () => {
      try {
        const { original, english } = await runPipeline(videoUri!, lang, mode === 'english',
          (label, pct) => setStep({ label, pct }));
        set({ original, english, clips: findHighlights(original) });
        navigation.replace('Clips');
      } catch (e: any) { setErr(e.message ?? String(e)); }
    })();
  }, []);

  return (
    <View style={[st.screen, { justifyContent: 'center' }]}>
      {err ? (
        <>
          <Text style={st.h1}>Processing stopped</Text>
          <Text style={{ color: c.danger }}>{err}</Text>
        </>
      ) : (
        <>
          <ActivityIndicator color={c.amber} size="large" />
          <Text style={[st.h1, { marginTop: 20 }]}>{step.label}</Text>
          <Text style={st.p}>{Math.round(step.pct * 100)}%. Keep the app open. Long videos take a few minutes.</Text>
        </>
      )}
    </View>
  );
}
