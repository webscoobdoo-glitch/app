import React, { useState } from 'react';
import { Text, View } from 'react-native';
import * as Sharing from 'expo-sharing';
import { useStore } from '../store';
import { exportClip } from '../services/exporter';
import { Aspect } from '../types';
import { Btn, Choice, st } from '../ui';
import { c } from '../theme';

export default function Export({ route }: any) {
  const { videoUri, clips, original, english, mode } = useStore();
  const clip = clips.find((x) => x.id === route.params.id)!;
  const [aspect, setAspect] = useState<Aspect>('9:16');
  const [height, setHeight] = useState<720 | 1080>(720);
  const [burn, setBurn] = useState(true);
  const [srt, setSrt] = useState(true);
  const [pct, setPct] = useState<number | null>(null);
  const [done, setDone] = useState<{ videoUri: string; srtPath?: string }>();
  const [err, setErr] = useState<string>();

  const run = async () => {
    setErr(undefined); setDone(undefined); setPct(0);
    try {
      const r = await exportClip({ videoUri: videoUri!, clip, aspect, height, burn: burn && mode !== 'none', srt, mode, original, english }, setPct);
      setDone(r);
    } catch (e: any) { setErr(e.message ?? String(e)); }
    setPct(null);
  };

  return (
    <View style={st.screen}>
      <Choice label="Shape" value={aspect} onChange={setAspect}
        options={[{ v: '9:16', t: 'Vertical 9:16' }, { v: '1:1', t: 'Square' }, { v: 'original', t: 'Original' }]} />
      <Choice label="Quality" value={height} onChange={setHeight}
        options={[{ v: 720, t: '720p' }, { v: 1080, t: '1080p' }]} />
      <Choice label="Captions in video" value={burn ? 'on' : 'off'} onChange={(v) => setBurn(v === 'on')}
        options={[{ v: 'on', t: 'Burned in' }, { v: 'off', t: 'Off' }]} />
      <Choice label="Caption file (.srt)" value={srt ? 'on' : 'off'} onChange={(v) => setSrt(v === 'on')}
        options={[{ v: 'on', t: 'Save' }, { v: 'off', t: 'Skip' }]} />

      <Btn label={pct === null ? 'Export clip' : `Exporting ${Math.round(pct * 100)}%`} onPress={run} disabled={pct !== null} />
      {err && <Text style={{ color: c.danger, marginTop: 12 }}>{err}</Text>}
      {done && (
        <View style={[st.card, { marginTop: 14 }]}>
          <Text style={{ color: c.text, marginBottom: 10 }}>Saved to your gallery in the ClipForge album.</Text>
          <Btn label="Share clip" quiet onPress={() => Sharing.shareAsync(done.videoUri)} />
          {done.srtPath && <><View style={{ height: 8 }} /><Btn label="Share captions (.srt)" quiet onPress={() => Sharing.shareAsync(done.srtPath!)} /></>}
        </View>
      )}
    </View>
  );
}
