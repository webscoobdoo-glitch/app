import React from 'react';
import { FlatList, Text, View } from 'react-native';
import { useStore } from '../store';
import { Btn, fmt, st } from '../ui';
import { c } from '../theme';

export default function Clips({ navigation }: any) {
  const clips = useStore((s) => s.clips);
  return (
    <View style={st.screen}>
      <FlatList data={clips} keyExtractor={(x) => x.id}
        ListEmptyComponent={<Text style={st.p}>No speech found. Try the manual editor on a different video.</Text>}
        renderItem={({ item }) => (
          <View style={st.card}>
            <Text style={{ color: c.amber, fontWeight: '700' }}>{fmt(item.startMs)} to {fmt(item.endMs)}</Text>
            <Text style={{ color: c.text, marginVertical: 8 }}>{item.title}</Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <View style={{ flex: 1 }}><Btn label="Trim" quiet onPress={() => navigation.navigate('Editor', { id: item.id })} /></View>
              <View style={{ flex: 1 }}><Btn label="Export" onPress={() => navigation.navigate('Export', { id: item.id })} /></View>
            </View>
          </View>
        )} />
    </View>
  );
}
