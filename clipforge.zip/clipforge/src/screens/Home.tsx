import React, { useEffect, useState } from 'react';
import { Text, View, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { useStore } from '../store';
import { hasModel, importModel } from '../services/pipeline';
import { Btn, Choice, st } from '../ui';

export default function Home({ navigation }: any) {
  const { videoUri, lang, mode, set } = useStore();
  const [model, setModel] = useState(false);
  useEffect(() => { hasModel().then(setModel); }, []);

  const pickVideo = async () => {
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['videos'] });
    if (!r.canceled) set({ videoUri: r.assets[0].uri });
  };
  const pickModel = async () => {
    const r = await DocumentPicker.getDocumentAsync({ copyToCacheDirectory: true });
    if (r.canceled) return;
    try { await importModel(r.assets[0].uri); setModel(true); }
    catch (e: any) { Alert.alert('Could not import model', e.message); }
  };

  return (
    <View style={st.screen}>
      <Text style={st.h1}>ClipForge</Text>
      <Text style={st.p}>Cut clips and add captions. Everything runs on this phone.</Text>

      {!model && (
        <View style={st.card}>
          <Text style={{ color: '#E8F1EF', marginBottom: 10 }}>
            Speech model missing. Import ggml-small-q5_1.bin once from your files.
          </Text>
          <Btn label="Import speech model" onPress={pickModel} quiet />
        </View>
      )}

      <Choice label="Spoken language" value={lang} onChange={(v) => set({ lang: v })}
        options={[{ v: 'auto', t: 'Auto' }, { v: 'te', t: 'Telugu' }, { v: 'hi', t: 'Hindi' }, { v: 'en', t: 'English' }]} />
      <Choice label="Captions" value={mode} onChange={(v) => set({ mode: v })}
        options={[{ v: 'english', t: 'English' }, { v: 'original', t: 'Original' }, { v: 'none', t: 'None' }]} />

      <Btn label={videoUri ? 'Change video' : 'Choose video'} onPress={pickVideo} quiet />
      <View style={{ height: 10 }} />
      <Btn label="Find clips" disabled={!videoUri || !model} onPress={() => navigation.navigate('Processing')} />
    </View>
  );
}
