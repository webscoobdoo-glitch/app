import React, { useEffect, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import Slider from '@react-native-community/slider';
import { useVideoPlayer, VideoView } from 'expo-video';
import { useStore } from '../store';
import { clipCues } from '../utils/srt';
import { Btn, fmt, st } from '../ui';
import { c } from '../theme';

export default function Editor({ route, navigation }: any) {
  const { videoUri, clips, original, set } = useStore();
  const clip = clips.find((x) => x.id === route.params.id)!;
  const [a, setA] = useState(clip.startMs);
  const [b, setB] = useState(clip.endMs);
  const player = useVideoPlayer(videoUri!, (p) => { p.currentTime = clip.startMs / 1000; });
  const total = Math.max(original[original.length - 1]?.endMs ?? b, b);

  useEffect(() => { player.currentTime = a / 1000; }, [a]);

  const save = () => {
    set({ clips: clips.map((x) => (x.id === clip.id ? { ...x, startMs: a, endMs: b } : x)) });
    navigation.navigate('Export', { id: clip.id });
  };

  return (
    <ScrollView style={st.screen}>
      <VideoView player={player} style={{ width: '100%', aspectRatio: 16 / 9, backgroundColor: '#000' }} nativeControls />
      <Text style={[st.label, { marginTop: 14 }]}>Start {fmt(a)}</Text>
      <Slider minimumValue={0} maximumValue={total} value={a} minimumTrackTintColor={c.amber} thumbTintColor={c.amber}
        onValueChange={(v) => setA(Math.min(v, b - 1000))} />
      <Text style={st.label}>End {fmt(b)}</Text>
      <Slider minimumValue={0} maximumValue={total} value={b} minimumTrackTintColor={c.amber} thumbTintColor={c.amber}
        onValueChange={(v) => setB(Math.max(v, a + 1000))} />
      <Text style={[st.label, { marginTop: 10 }]}>Transcript in this clip</Text>
      {clipCues(original, { ...clip, startMs: a, endMs: b }).map((q, i) => (
        <Text key={i} style={{ color: c.text, marginBottom: 6 }}>{q.text}</Text>
      ))}
      <View style={{ height: 14 }} />
      <Btn label="Save and export" onPress={save} />
    </ScrollView>
  );
}
