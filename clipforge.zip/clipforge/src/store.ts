import { create } from 'zustand';
import { CaptionMode, Clip, Lang, Seg } from './types';

type S = {
  videoUri?: string; lang: Lang; mode: CaptionMode;
  original: Seg[]; english: Seg[]; clips: Clip[];
  set: (p: Partial<S>) => void;
};
// In-memory for now. TODO: persist projects with expo-sqlite.
export const useStore = create<S>((set) => ({
  lang: 'auto', mode: 'english', original: [], english: [], clips: [],
  set: (p) => set(p),
}));
