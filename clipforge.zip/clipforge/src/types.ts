export type Seg = { startMs: number; endMs: number; text: string };
export type Clip = { id: string; startMs: number; endMs: number; title: string; score: number };
export type Lang = 'auto' | 'te' | 'hi' | 'en';
export type CaptionMode = 'none' | 'original' | 'english';
export type Aspect = '9:16' | '1:1' | 'original';
