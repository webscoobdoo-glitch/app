import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import VideoEditor from '../native/VideoEditor';
import { Aspect, CaptionMode, Clip, Seg } from '../types';
import { clipCues, toSrt } from '../utils/srt';

export type ExportOpts = {
  videoUri: string; clip: Clip; aspect: Aspect; height: 720 | 1080;
  burn: boolean; srt: boolean; mode: CaptionMode; original: Seg[]; english: Seg[];
};

export async function exportClip(o: ExportOpts, onProgress: (p: number) => void) {
  const segs = o.mode === 'english' ? o.english : o.mode === 'original' ? o.original : [];
  const cues = o.burn ? clipCues(segs, o.clip) : [];
  const out = FileSystem.cacheDirectory + `clip-${o.clip.id}-${Date.now()}.mp4`;

  const sub = VideoEditor.addListener('onProgress', (e) => onProgress(e.progress));
  try {
    await VideoEditor.trim({
      inputUri: o.videoUri, outputPath: out.replace('file://', ''),
      startMs: o.clip.startMs, endMs: o.clip.endMs,
      aspect: o.aspect, height: o.height, cues,
    });
  } finally { sub.remove(); }

  const perm = await MediaLibrary.requestPermissionsAsync(true);
  if (!perm.granted) throw new Error('Allow media access so the clip can be saved to your gallery.');
  const asset = await MediaLibrary.createAssetAsync(out);
  await MediaLibrary.createAlbumAsync('ClipForge', asset, false).catch(() => {});

  let srtPath: string | undefined;
  if (o.srt && segs.length) {
    srtPath = FileSystem.documentDirectory + `clip-${o.clip.id}.${o.mode}.srt`;
    await FileSystem.writeAsStringAsync(srtPath, toSrt(clipCues(segs, o.clip)));
  }
  return { videoUri: out, srtPath };
}
