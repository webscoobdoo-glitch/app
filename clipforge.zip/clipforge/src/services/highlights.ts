import { Seg, Clip } from '../types';

const MIN = 15000, MAX = 60000, TARGET = 30000;

/** Offline heuristic: sentence-aligned windows scored by speech density, length fit and emphasis. */
export function findHighlights(segs: Seg[], count = 5): Clip[] {
  const cands: Clip[] = [];
  for (let i = 0; i < segs.length; i++) {
    let words = 0, punch = 0;
    for (let j = i; j < segs.length; j++) {
      const dur = segs[j].endMs - segs[i].startMs;
      if (dur > MAX) break;
      const t = segs[j].text.trim();
      words += t.split(/\s+/).filter(Boolean).length;
      punch += (t.match(/[?!]/g) || []).length;
      if (dur >= MIN && /[.?!।]$/.test(t)) {
        const density = words / (dur / 1000);
        const fit = 1 - Math.abs(dur - TARGET) / TARGET;
        cands.push({
          id: `${i}-${j}`, startMs: segs[i].startMs, endMs: segs[j].endMs,
          title: segs[i].text.trim().slice(0, 48),
          score: density * 0.6 + fit * 0.3 + Math.min(punch, 3) * 0.1,
        });
      }
    }
  }
  const picked: Clip[] = [];
  for (const cand of cands.sort((a, b) => b.score - a.score)) {
    if (picked.length >= count) break;
    if (picked.every((p) => cand.endMs <= p.startMs || cand.startMs >= p.endMs)) picked.push(cand);
  }
  if (!picked.length && segs.length) { // fallback: fixed 30s chunks
    const end = segs[segs.length - 1].endMs;
    for (let t = 0, k = 0; t < end && k < count; t += TARGET, k++)
      picked.push({ id: `chunk-${k}`, startMs: t, endMs: Math.min(t + TARGET, end), title: `Part ${k + 1}`, score: 0 });
  }
  return picked.sort((a, b) => a.startMs - b.startMs);
}
