import { initWhisper } from 'whisper.rn';
import * as FileSystem from 'expo-file-system';
import VideoEditor from '../native/VideoEditor';
import { Lang, Seg } from '../types';

export const MODEL_PATH = FileSystem.documentDirectory + 'models/ggml-small-q5_1.bin';
const strip = (u: string) => u.replace('file://', '');

export async function hasModel() {
  return (await FileSystem.getInfoAsync(MODEL_PATH)).exists;
}
export async function importModel(pickedUri: string) {
  await FileSystem.makeDirectoryAsync(FileSystem.documentDirectory + 'models/', { intermediates: true }).catch(() => {});
  await FileSystem.copyAsync({ from: pickedUri, to: MODEL_PATH });
}

// whisper.cpp segment times are in 10 ms units (verify against your whisper.rn version).
const toSegs = (r: { segments: { text: string; t0: number; t1: number }[] }): Seg[] =>
  r.segments.map((s) => ({ startMs: s.t0 * 10, endMs: s.t1 * 10, text: s.text }));

export async function runPipeline(
  videoUri: string, lang: Lang, wantEnglish: boolean,
  onStep: (label: string, pct: number) => void,
) {
  const dir = FileSystem.cacheDirectory + 'work/';
  await FileSystem.makeDirectoryAsync(dir, { intermediates: true }).catch(() => {});
  const wav = strip(dir + 'audio.wav');

  onStep('Extracting audio', 0.05);
  await VideoEditor.extractAudioWav(videoUri, wav);

  const ctx = await initWhisper({ filePath: strip(MODEL_PATH) });
  const language = lang === 'auto' ? undefined : lang;

  onStep('Transcribing', 0.1);
  const orig = await ctx.transcribe(wav, {
    language, onProgress: (p: number) => onStep('Transcribing', 0.1 + (p / 100) * 0.5),
  }).promise;
  const original = toSegs(orig);

  let english: Seg[] = [];
  if (wantEnglish && lang !== 'en') {
    onStep('Translating to English', 0.6);
    // Whisper's built-in translate task: fully offline, no extra model.
    const tr = await ctx.transcribe(wav, { language, translate: true }).promise;
    english = toSegs(tr);
  }
  await ctx.release();
  onStep('Done', 1);
  return { original, english };
}
