# ClipForge (offline video clipper, Android first)

Pick a video, transcribe it on-device (Whisper), get English or original captions,
auto-suggest highlight clips, trim by hand, export MP4 + .srt. No internet needed at runtime.

## Setup
1. `npx create-expo-app@latest clipforge --template blank-typescript`
2. Copy `App.tsx` and `src/` from this folder into it.
3. Install JS deps:
   `npx expo install expo-image-picker expo-document-picker expo-file-system expo-media-library expo-sharing expo-video expo-modules-core react-native-screens react-native-safe-area-context @react-native-community/slider`
   `npm i whisper.rn zustand @react-navigation/native @react-navigation/native-stack`
4. Create the native module: `npx create-expo-module@latest --local video-editor`
   - Replace the generated `android/src/main/java/expo/modules/videoeditor/VideoEditorModule.kt`
     with `native-module/.../VideoEditorModule.kt`
   - Add the Media3 lines from `native-module/android-gradle-deps.txt` to its `build.gradle`
   - Keep only the `android` platform in its `expo-module.config.json`
5. Get the speech model once: `ggml-small-q5_1.bin` from the whisper.cpp model list on Hugging Face.
   Put it on the phone (Downloads). The app's "Import speech model" button copies it in. Needs a multilingual model (no `.en`).
6. Build and run (no Expo Go): `npx expo run:android`

## Status: NOT yet compiled or run on a device
Tested here: highlight scoring and SRT generation (pure TypeScript).
Untested, expect small fixes: the Kotlin module (Media3 APIs shift between versions, audio decode loop),
whisper.rn option names and segment time units, expo-video/media-library permissions on your Android version.

## Known limits
- English captions use Whisper's translate task. Good for Hindi, weaker for Telugu. Review before posting.
- Burned-in caption text is a single line (no wrapping yet), so keep cues short.
- Highlights are heuristic (speech density, sentence ends, length). No AI ranking yet.
- Projects are in memory only. Persist with expo-sqlite next.
