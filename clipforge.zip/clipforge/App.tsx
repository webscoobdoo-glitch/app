import React from 'react';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './src/screens/Home';
import Processing from './src/screens/Processing';
import Clips from './src/screens/Clips';
import Editor from './src/screens/Editor';
import Export from './src/screens/Export';
import { c } from './src/theme';

const Stack = createNativeStackNavigator();
const theme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: c.bg, card: c.bg, text: c.text } };

export default function App() {
  return (
    <NavigationContainer theme={theme}>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={Home} options={{ headerShown: false }} />
        <Stack.Screen name="Processing" component={Processing} options={{ title: 'Working', headerBackVisible: false }} />
        <Stack.Screen name="Clips" component={Clips} options={{ title: 'Suggested clips' }} />
        <Stack.Screen name="Editor" component={Editor} options={{ title: 'Trim' }} />
        <Stack.Screen name="Export" component={Export} options={{ title: 'Export' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
