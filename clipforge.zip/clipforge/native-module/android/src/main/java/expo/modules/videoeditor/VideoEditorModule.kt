package expo.modules.videoeditor

import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Spannable
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import expo.modules.kotlin.Promise
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import expo.modules.kotlin.records.Field
import expo.modules.kotlin.records.Record
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

class Cue : Record {
  @Field val startMs: Long = 0
  @Field val endMs: Long = 0
  @Field val text: String = ""
}

class TrimOptions : Record {
  @Field val inputUri: String = ""
  @Field val outputPath: String = ""
  @Field val startMs: Long = 0
  @Field val endMs: Long = 0
  @Field val aspect: String = "original"
  @Field val height: Int = 720
  @Field val cues: List<Cue> = emptyList()
}

@UnstableApi
class VideoEditorModule : Module() {
  private val ctx get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()
  private val main = Handler(Looper.getMainLooper())

  override fun definition() = ModuleDefinition {
    Name("VideoEditor")
    Events("onProgress")

    // 16 kHz mono 16-bit WAV, the input whisper.cpp expects.
    AsyncFunction("extractAudioWav") { inputUri: String, outPath: String ->
      decodeToWav16k(Uri.parse(inputUri), File(outPath))
    }

    // Transformer must be driven from a thread with a Looper, so hop to main.
    AsyncFunction("trim") { o: TrimOptions, promise: Promise -> main.post { startTrim(o, promise) } }
  }

  private fun startTrim(o: TrimOptions, promise: Promise) {
    try {
      val clipping = MediaItem.ClippingConfiguration.Builder()
        .setStartPositionMs(o.startMs).setEndPositionMs(o.endMs).build()
      val item = MediaItem.Builder().setUri(o.inputUri).setClippingConfiguration(clipping).build()

      val video = mutableListOf<Effect>()
      when (o.aspect) {
        "9:16" -> video.add(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
        "1:1" -> video.add(Presentation.createForAspectRatio(1f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
      }
      video.add(Presentation.createForHeight(o.height))
      if (o.cues.isNotEmpty()) video.add(OverlayEffect(listOf(CaptionOverlay(o.cues))))

      val edited = EditedMediaItem.Builder(item).setEffects(Effects(emptyList(), video)).build()
      var active = true
      val transformer = Transformer.Builder(ctx)
        .setVideoMimeType(MimeTypes.VIDEO_H264)
        .setAudioMimeType(MimeTypes.AUDIO_AAC)
        .addListener(object : Transformer.Listener {
          override fun onCompleted(composition: Composition, exportResult: ExportResult) {
            active = false; promise.resolve(o.outputPath)
          }
          override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
            active = false; promise.reject("E_EXPORT", exportException.message, exportException)
          }
        }).build()

      File(o.outputPath).delete()
      transformer.start(edited, o.outputPath)

      val holder = ProgressHolder()
      val tick = object : Runnable {
        override fun run() {
          if (!active) return
          if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED)
            sendEvent("onProgress", mapOf("progress" to holder.progress / 100f))
          main.postDelayed(this, 400)
        }
      }
      main.post(tick)
    } catch (e: Exception) {
      promise.reject("E_EXPORT", e.message, e)
    }
  }

  /** Draws the cue active at the current frame near the bottom of the video. Cue times are clip-relative. */
  private class CaptionOverlay(private val cues: List<Cue>) : TextOverlay() {
    private val settings = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.72f).build()

    override fun getText(presentationTimeUs: Long): SpannableString {
      val ms = presentationTimeUs / 1000
      val cue = cues.firstOrNull { ms >= it.startMs && ms < it.endMs }
      val s = SpannableString(cue?.text ?: " ")
      val f = Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
      s.setSpan(ForegroundColorSpan(Color.WHITE), 0, s.length, f)
      s.setSpan(AbsoluteSizeSpan(44), 0, s.length, f)
      if (cue != null) s.setSpan(BackgroundColorSpan(0x99000000.toInt()), 0, s.length, f)
      return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long) = settings
  }

  private fun decodeToWav16k(uri: Uri, out: File) {
    val ex = MediaExtractor()
    ex.setDataSource(ctx, uri, null)
    val idx = (0 until ex.trackCount).firstOrNull {
      ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
    } ?: throw IllegalStateException("This video has no audio track.")
    ex.selectTrack(idx)
    val fmt = ex.getTrackFormat(idx)
    val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
    codec.configure(fmt, null, null, 0)
    codec.start()

    val raf = RandomAccessFile(out, "rw")
    raf.setLength(0)
    raf.write(ByteArray(44))
    var srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
    var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
    var acc = 0.0
    var dataBytes = 0L
    val info = MediaCodec.BufferInfo()
    var inDone = false
    var outDone = false

    while (!outDone) {
      if (!inDone) {
        val i = codec.dequeueInputBuffer(10_000)
        if (i >= 0) {
          val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
          if (n < 0) {
            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true
          } else {
            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance()
          }
        }
      }
      val o = codec.dequeueOutputBuffer(info, 10_000)
      if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
        val f = codec.outputFormat
        srcRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
      } else if (o >= 0) {
        val bb = codec.getOutputBuffer(o)!!
        bb.position(info.offset); bb.limit(info.offset + info.size)
        val sb = bb.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val chunk = ByteArrayOutputStream()
        val step = 16000.0 / srcRate
        while (sb.remaining() >= ch) {
          var sum = 0
          repeat(ch) { sum += sb.get() }
          acc += step
          if (acc >= 1.0) { // naive decimation, good enough for speech
            acc -= 1.0
            val m = (sum / ch).coerceIn(-32768, 32767)
            chunk.write(m and 0xFF); chunk.write((m shr 8) and 0xFF)
          }
        }
        raf.write(chunk.toByteArray()); dataBytes += chunk.size()
        codec.releaseOutputBuffer(o, false)
        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
      }
    }
    codec.stop(); codec.release(); ex.release()

    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
    h.put("RIFF".toByteArray()); h.putInt((36 + dataBytes).toInt()); h.put("WAVE".toByteArray())
    h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
    h.putInt(16000); h.putInt(32000); h.putShort(2); h.putShort(16)
    h.put("data".toByteArray()); h.putInt(dataBytes.toInt())
    raf.seek(0); raf.write(h.array()); raf.close()
  }
}
